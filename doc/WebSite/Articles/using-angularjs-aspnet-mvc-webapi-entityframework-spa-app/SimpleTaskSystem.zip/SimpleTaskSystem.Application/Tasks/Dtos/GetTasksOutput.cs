﻿using System.Collections.Generic;

namespace SimpleTaskSystem.Tasks.Dtos
{
    public class GetTasksOutput
    {
        public List<TaskDto> Tasks { get; set; } 
    }
}