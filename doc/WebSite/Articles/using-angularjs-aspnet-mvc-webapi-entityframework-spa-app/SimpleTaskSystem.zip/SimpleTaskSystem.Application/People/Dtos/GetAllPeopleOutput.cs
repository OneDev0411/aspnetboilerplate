﻿using System.Collections.Generic;

namespace SimpleTaskSystem.People.Dtos
{
    public class GetAllPeopleOutput
    {
        public List<PersonDto> People { get; set; }
    }
}