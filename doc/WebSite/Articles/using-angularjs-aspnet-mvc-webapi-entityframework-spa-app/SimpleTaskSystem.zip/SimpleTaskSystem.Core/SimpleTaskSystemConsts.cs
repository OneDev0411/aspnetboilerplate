﻿namespace SimpleTaskSystem
{
    public class SimpleTaskSystemConsts
    {
        public const string LocalizationSourceName = "SimpleTaskSystem";
    }
}